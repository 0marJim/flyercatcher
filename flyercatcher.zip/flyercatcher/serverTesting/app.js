
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm';

const supabase = createClient(
  // ① paste just the URL
  'https://cnywnmqnoargrczwkcki.supabase.co',

  // ② paste just the long anon key
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNueXdubXFub2FyZ3JjendrY2tpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk5MDI2MDYsImV4cCI6MjA3NTQ3ODYwNn0.ZzlzoaCT4LNTUJ30C68g5TJi43OMVq7RCBbietfpwDY'
);

document.getElementById('saveBtn').addEventListener('click', async () => {
  const name = document.getElementById('nameInput').value.trim();
  if (!name) return (document.getElementById('status').textContent = 'Name required.');

  const { error } = await supabase.from('events').insert({ name });
  document.getElementById('status').textContent =
    error ? `Error: ${error.message}` : 'Saved!  Check Supabase.';
});


