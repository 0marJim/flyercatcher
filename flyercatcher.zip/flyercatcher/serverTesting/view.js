import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm';

const supabase = createClient(
  // ① paste just the URL
  'https://cnywnmqnoargrczwkcki.supabase.co',

  // ② paste just the long anon key
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNueXdubXFub2FyZ3JjendrY2tpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk5MDI2MDYsImV4cCI6MjA3NTQ3ODYwNn0.ZzlzoaCT4LNTUJ30C68g5TJi43OMVq7RCBbietfpwDY'
);

async function loadEvents() {
  const { data, error } = await supabase
    .from('events')
    .select('*')
    .order('id', { ascending: true });

  const list = document.getElementById('eventsList');
  list.innerHTML = '';

  if (error) {
    list.innerHTML = `<li style="color:red">${error.message}</li>`;
    return;
  }

  data.forEach(row => {
    const li = document.createElement('li');
    li.textContent = `[${row.id}]  ${row.name}`;
    list.appendChild(li);
  });
}

document.getElementById('refreshBtn').addEventListener('click', loadEvents);

// auto-load once on page open
loadEvents();
